import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ci-users',
  templateUrl: './ci-users.component.html',
  styleUrls: ['./ci-users.component.css']
})
export class CiUsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
