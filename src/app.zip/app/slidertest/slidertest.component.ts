import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slidertest',
  templateUrl: './slidertest.component.html',
  styleUrls: ['./slidertest.component.css']
})
export class SlidertestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
