export interface Userdatas {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  mobileNumber: number;
}
